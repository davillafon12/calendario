CREATE TABLE IF NOT EXISTS turno ( 
   id bigint auto_increment NOT NULL, 
   numero int NOT NULL, 
   dias VARCHAR(15) NOT NULL
);